const form = document.getElementById("calculator-form");
const resultsBody = document.getElementById("results-body");
const resultSummary = document.getElementById("result-summary");
const parametersStrip = document.getElementById("parameters-strip");
const messageBox = document.getElementById("message-box");
const bInput = document.getElementById("b-input");
const e2Input = document.getElementById("e2-input");
const resetButton = document.getElementById("reset-button");
const batchFileInput = document.getElementById("batch-file");
const dropZone = document.getElementById("drop-zone");
const processBatchButton = document.getElementById("process-batch");
const fileInfo = document.getElementById("file-info");
const batchMessage = document.getElementById("batch-message");

let calculationTimer;
let selectedBatchFile = null;

const sample = {
  Material: "ASS",
  fy_MPa_theta: 380,
  fu_MPa_theta: 513.2,
  fub_MPa: 800,
  t_mm: 3.43,
  db_mm: 18,
  dh_mm: 20,
  b_mm: 140,
  e1_mm: 30,
  e2_mm: 70,
};

function setMessage(element, messages = [], type = "error") {
  if (!messages.length) {
    element.className = "message-box";
    element.textContent = "";
    return;
  }
  element.className = `message-box show ${type}`;
  element.innerHTML = messages.map((message) => `<div>${escapeHtml(message)}</div>`).join("");
}

function escapeHtml(value) {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function formData() {
  return Object.fromEntries(new FormData(form).entries());
}

function scheduleCalculation() {
  clearTimeout(calculationTimer);
  calculationTimer = setTimeout(calculate, 180);
}

async function calculate() {
  try {
    const response = await fetch("/api/calculate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(formData()),
    });
    const payload = await response.json();
    if (!response.ok) {
      setMessage(messageBox, payload.errors || ["Invalid input."]);
      return;
    }
    renderResults(payload);
    setMessage(messageBox, payload.warnings || [], "warning");
  } catch (error) {
    setMessage(messageBox, [`Unable to connect to the local calculation service: ${error.message}`]);
  }
}

function renderResults(payload) {
  const methods = payload.methods;
  const values = methods.map((method) => method.resistance);
  const minimum = Math.min(...values);
  const maximum = Math.max(...values);
  resultSummary.classList.remove("skeleton");
  resultSummary.innerHTML = `
    <span>Range across eight methods</span>
    <strong>${minimum.toFixed(2)} – ${maximum.toFixed(2)} kN</strong>
  `;
  resultsBody.innerHTML = methods
    .map((method) => {
      const width = maximum ? (method.resistance / maximum) * 100 : 0;
      const family = method.key.startsWith("pro,")
        ? "Proposed method"
        : method.key === "Literature"
          ? "Literature"
          : "Design standard";
      return `
        <tr>
          <td><span class="method-name">${escapeHtml(method.method)}<small>${family}</small></span></td>
          <td><span class="resistance">${method.resistance.toFixed(2)} <small>kN</small></span></td>
          <td><span class="mode-badge ${method.mode.toLowerCase()}">${method.mode}</span></td>
          <td><div class="bar-track"><div class="bar-fill" style="width:${width.toFixed(1)}%"></div></div></td>
        </tr>
      `;
    })
    .join("");

  const parameters = payload.parameters;
  parametersStrip.innerHTML = `
    <span>k<sub>m, EC3-8</sub> = ${parameters["km_EC3-8"].toFixed(2)}</span>
    <span>k<sub>1, EC3-4</sub> = ${parameters["k1_EC3-4"].toFixed(2)}</span>
    <span>α<sub>b, EC3-8</sub> = ${parameters["alpha_b_EC3-8"].toFixed(3)}</span>
    <span>α<sub>b, Pro-gv</sub> = ${parameters["alpha_b_pro_gv"].toFixed(3)}</span>
  `;
}

form.addEventListener("input", (event) => {
  if (event.target === e2Input && e2Input.value !== "") {
    bInput.value = formatLinked(Number(e2Input.value) * 2);
  }
  if (event.target === bInput && bInput.value !== "") {
    e2Input.value = formatLinked(Number(bInput.value) / 2);
  }
  scheduleCalculation();
});

function formatLinked(value) {
  return Number.isFinite(value) ? Number(value.toFixed(6)).toString() : "";
}

resetButton.addEventListener("click", () => {
  Object.entries(sample).forEach(([name, value]) => {
    form.elements[name].value = value;
  });
  calculate();
});

document.querySelectorAll(".tab").forEach((tab) => {
  tab.addEventListener("click", () => {
    document.querySelectorAll(".tab").forEach((item) => item.classList.remove("active"));
    document.querySelectorAll(".tab-panel").forEach((panel) => panel.classList.remove("active"));
    tab.classList.add("active");
    document.getElementById(`${tab.dataset.tab}-panel`).classList.add("active");
  });
});

function selectBatchFile(file) {
  if (!file) return;
  const valid = file.name.toLowerCase().endsWith(".xlsx") || file.name.toLowerCase().endsWith(".csv");
  if (!valid) {
    selectedBatchFile = null;
    processBatchButton.disabled = true;
    fileInfo.textContent = "";
    setMessage(batchMessage, ["Select an .xlsx or .csv file."]);
    return;
  }
  selectedBatchFile = file;
  processBatchButton.disabled = false;
  fileInfo.textContent = `${file.name} · ${(file.size / 1024).toFixed(1)} KB`;
  setMessage(batchMessage);
}

dropZone.addEventListener("click", () => batchFileInput.click());
batchFileInput.addEventListener("change", () => selectBatchFile(batchFileInput.files[0]));
["dragenter", "dragover"].forEach((type) => {
  dropZone.addEventListener(type, (event) => {
    event.preventDefault();
    dropZone.classList.add("dragover");
  });
});
["dragleave", "drop"].forEach((type) => {
  dropZone.addEventListener(type, (event) => {
    event.preventDefault();
    dropZone.classList.remove("dragover");
  });
});
dropZone.addEventListener("drop", (event) => selectBatchFile(event.dataTransfer.files[0]));

processBatchButton.addEventListener("click", async () => {
  if (!selectedBatchFile) return;
  processBatchButton.disabled = true;
  processBatchButton.textContent = "Calculating…";
  setMessage(batchMessage);
  try {
    const response = await fetch("/api/batch", {
      method: "POST",
      headers: { "X-Filename": selectedBatchFile.name },
      body: await selectedBatchFile.arrayBuffer(),
    });
    if (!response.ok) {
      const payload = await response.json();
      throw new Error((payload.errors || ["Processing failed."]).join("; "));
    }
    const blob = await response.blob();
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.download = "bolted_connection_batch_results.xlsx";
    anchor.click();
    URL.revokeObjectURL(url);
    const processed = response.headers.get("X-Processed-Rows") || "0";
    const errors = response.headers.get("X-Error-Rows") || "0";
    setMessage(
      batchMessage,
      [`Completed ${processed} valid row(s); ${errors} row(s) contain validation errors. The result workbook has been exported.`],
      errors === "0" ? "success" : "warning",
    );
  } catch (error) {
    setMessage(batchMessage, [error.message]);
  } finally {
    processBatchButton.disabled = false;
    processBatchButton.textContent = "Calculate and Export Results";
  }
});

calculate();
