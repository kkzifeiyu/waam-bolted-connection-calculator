"""Offline local web server for the bolted connection calculator."""

from __future__ import annotations

import argparse
import json
import mimetypes
import sys
import threading
import webbrowser
import zipfile
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

from calculator import INPUT_COLUMNS, OUTPUT_COLUMNS, ValidationError, calculate
from xlsx_io import read_csv, read_xlsx, write_xlsx


ROOT = Path(__file__).resolve().parent
STATIC_FILES = {"", "index.html", "app.js", "styles.css"}


def _template_rows() -> list[list[object]]:
    return [
        ["ASS", 380, 513.2, 800, 3.43, 18, 19.68, 140.65, 29.59, 70.325],
        ["DSS", 550, 720, 800, 5, 24, 27, 135, 52, 67.5],
    ]


class Handler(BaseHTTPRequestHandler):
    server_version = "BoltedConnectionCalculator/1.0"

    def log_message(self, format: str, *args: object) -> None:
        sys.stdout.write(f"{self.address_string()} - {format % args}\n")

    def _send_bytes(
        self,
        content: bytes,
        content_type: str,
        status: HTTPStatus = HTTPStatus.OK,
        headers: dict[str, str] | None = None,
    ) -> None:
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Cache-Control", "no-store")
        for key, value in (headers or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(content)

    def _send_json(
        self, payload: object, status: HTTPStatus = HTTPStatus.OK
    ) -> None:
        self._send_bytes(
            json.dumps(payload, ensure_ascii=False).encode("utf-8"),
            "application/json; charset=utf-8",
            status,
        )

    def do_GET(self) -> None:
        path = unquote(urlparse(self.path).path).lstrip("/")
        if path == "api/health":
            self._send_json({"ok": True})
            return
        if path == "api/template":
            content = write_xlsx(INPUT_COLUMNS, _template_rows(), "Batch_input")
            self._send_bytes(
                content,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                headers={
                    "Content-Disposition": 'attachment; filename="bolted_connection_batch_template.xlsx"'
                },
            )
            return
        if path not in STATIC_FILES:
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        file_path = ROOT / ("index.html" if path == "" else path)
        if not file_path.is_file():
            self.send_error(HTTPStatus.NOT_FOUND)
            return
        mime_type = mimetypes.guess_type(file_path.name)[0] or "application/octet-stream"
        self._send_bytes(file_path.read_bytes(), f"{mime_type}; charset=utf-8")

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        content_length = int(self.headers.get("Content-Length", "0"))
        content = self.rfile.read(content_length)

        if path == "/api/calculate":
            try:
                payload = json.loads(content.decode("utf-8"))
                self._send_json(calculate(payload))
            except ValidationError as exc:
                self._send_json(
                    {"errors": exc.errors, "warnings": exc.warnings},
                    HTTPStatus.UNPROCESSABLE_ENTITY,
                )
            except (json.JSONDecodeError, TypeError) as exc:
                self._send_json(
                    {"errors": [f"Unable to read the input: {exc}"]},
                    HTTPStatus.BAD_REQUEST,
                )
            return

        if path == "/api/batch":
            filename = self.headers.get("X-Filename", "batch.xlsx")
            try:
                if filename.lower().endswith(".csv"):
                    records = read_csv(content)
                else:
                    records = read_xlsx(content)
                if not records:
                    raise ValueError("The file does not contain any data rows.")
                output_rows: list[list[object]] = []
                success_count = 0
                error_count = 0
                for row_number, record in enumerate(records, start=2):
                    try:
                        result = calculate(record)
                        normalized = result["inputs"]
                        output_rows.append(
                            [normalized[column] for column in INPUT_COLUMNS]
                            + [
                                result["results"][column]
                                for column in OUTPUT_COLUMNS
                            ]
                            + ["; ".join(result["warnings"]), ""]
                        )
                        success_count += 1
                    except ValidationError as exc:
                        output_rows.append(
                            [record.get(column, "") for column in INPUT_COLUMNS]
                            + [""] * len(OUTPUT_COLUMNS)
                            + ["; ".join(exc.warnings), f"Row {row_number}: {'; '.join(exc.errors)}"]
                        )
                        error_count += 1
                output = write_xlsx(
                    INPUT_COLUMNS + OUTPUT_COLUMNS + ["Warnings", "Errors"],
                    output_rows,
                    "Batch_results",
                )
                self._send_bytes(
                    output,
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={
                        "Content-Disposition": 'attachment; filename="bolted_connection_batch_results.xlsx"',
                        "X-Processed-Rows": str(success_count),
                        "X-Error-Rows": str(error_count),
                        "Access-Control-Expose-Headers": "X-Processed-Rows, X-Error-Rows",
                    },
                )
            except (ValueError, zipfile.BadZipFile) as exc:
                self._send_json(
                    {"errors": [f"Batch file processing failed: {exc}"]},
                    HTTPStatus.UNPROCESSABLE_ENTITY,
                )
            except Exception as exc:
                self._send_json(
                    {"errors": [f"Batch file processing failed: {exc}"]},
                    HTTPStatus.INTERNAL_SERVER_ERROR,
                )
            return

        self.send_error(HTTPStatus.NOT_FOUND)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", default=8765, type=int)
    parser.add_argument("--open", action="store_true")
    args = parser.parse_args()
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    url = f"http://{args.host}:{args.port}"
    print(f"Bolted Connection Calculator: {url}")
    if args.open:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
